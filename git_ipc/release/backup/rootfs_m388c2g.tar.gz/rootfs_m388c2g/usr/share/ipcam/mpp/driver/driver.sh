insmod ./Godshand.ko
insmod ./vma_h4cde.ko
insmod ./vma_ispe.ko
insmod ./vma_jebe.ko
insmod ./vma_meae.ko
insmod ./vpl_dmac.ko
insmod ./vpl_edmc.ko
insmod ./dwc_otg.ko host_only=1
insmod ./rtl8188eus.ko
sh sensor.sh
