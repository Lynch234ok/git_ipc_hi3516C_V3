
var langstr={
	//index page
	title : "IP Camera",
	preview :	"live",
	setup :		"setup",
	console :	"console",
	record :	"record",
	playback:	"play",
	zoom :		"zoom",
	zoom_in:	"Zoom In",
	zoom_out:	"Zoom Out",
	full_screen :	"full screen",
	stream_change:	"stream switch",
	main_stream :	"main stream",
	sub_stream :	"sub stream",
	
	helper :	"Help Message Box",
	update_preview:	"Udate preview now...",
	//menu
	media:		"Media",
		video:		"Video setup",
		image:		"Image setup",
	network:	"Network setup",
		local:		"Local setup",
		remote:		"Remote setup",
	advance_setup:	"Advance setup",
		usermanage:	"User Management",
	system:		"System setup",
		time:		"Time Setup",
		initial:		"Iniliazation",
		devinfo:	"Device Info",
	
	//save button
	save_video:	"save video configure",
	save_image:	"save image configure",
	save_local: "save local network configure",
	save_remote: "save remote network configure",
	save_time: "save time configure",
	save_init: "save initialization configure",
	//common
	ok:		"ok",
	cancel:	"cancel",
	save:	"save",
	save_setup:	"Saving setting now...",
	save_refresh:	"save setup success ,please refresh this page.",
	save_preview:	"Create  a new preview, please save.",
	format_wrong:	"Format is wrong , the right format must like this :",
	port_wrong:		"Port is wrong , it must be a number",
	delete_confirm:	"Do you want to delete it now?",
	delete_fail:	"Delete failed.",
	add_fail:		"Add failed.",
	old_pwd_wrong:	"Old password wrong.",
	confirm_pwd_wrong:	"confirm password wrong.",
	modify_pwd_fail:	"modify password fail.",
	delete:				"delete",
	close:			"close",
	reboot_refresh:	"Rebooing now, please refresh this page after a while.",
	sync_time_now:	"Sync. time now.",
	sync_refresh:	"Sync. success,please refresh this page.",
	
	//video 
	shutter:	"Shutter",
	m_stream:	"Main Stream",
	s_stream1:	"Sub Stream 1",	
	s_stream2:	"Sub Stream 2",
	resolution:	"Resolution",
	bps:	"Bit Rate",
		fix:	"fixed",
		volatile:	"volatile",	
	fps:	"Frame Rate",
	quality:	"Codec Quality",
		best:	"best",
		good:	"good",
		normal:	"normal",
		bad:	"bad",
		worst:	"worst",
		
	//image
	hue:	"Hue",
	contrast:	"Contrast",
	brightness:	"Brightness",
	saturation:	"Saturation",
	
	/////////Network
	// local
	mac:	"MAC",
	dhcp:	"DHCP State",
		open:	"Open",
		close:	"close",
	esee:	"ESEE State",
	ip:		"IP Address",
	gateway:	"Gateway",
	netmask:	"Netmask",
	dns0:		"Preferred DNS",
	dns1:		"Alternate DNS",
	port:		"port",
	// remote-ddns
	ddns_set:	"DDNS Setup",
	ddns:		"DDNS State",
	server:		"Server",
	domain:		"Domain",
	user:		"User",
	password:	"Password",
	// remote-pppoe
	pppoe_set:	"PPPoE Setup",
	pppoe:		"PPPoE State",
	
	//////advanced setup
	//user management
	username:	 "User Name",
	authority:		"Authority",
	operation:		"operation",
	update_list	:		"UpdateList",
	adduser:		"Add User",
	changepwd:		"Change Password",
	oldpwd:			"Old Password",
	newpwd:			"New Password",
	confirmpwd:		"Confirm Password",

	//////system setup
	//time
	dev_time:	"Device Time",
	date_frt:	"Date Format",
		date_frt1:	"YMD: xxxx xx xx",
		date_frt2:	"MDY: xx xx xxxx",
		date_frt3:	"DMY: xx xx xxxx",
	date_del:	"Time Delimiter",
		date_del1:	"xxxx-xx-xx",
		date_del2:	"xxxx/xx/xx",
		date_del3:	"xxxx.xx.xx",
	time_zone:	"Time Zone",
	daylightt:	"Daylight Saving Time",
	manual_set:	"Manually Setup",
	date:	"Date",
	time:	"Time",
	sync_pc_time:	"Local Time Sync.",
	pc_time:	"Computer Time",
	sync:		"Sync",
	sync_ntp_time:	"NTP Time Sync.",
	ntp:		"NTP Server Sync. State",
	ntp_server:	"NTP Server",
	
	//reboot
	reboot_tip:	"Click button below to reboot IP Camera.",
	reboot:	"Reboot Now...",
	
	//restore factory setup
	restore_tip:	"Click button below to restore default factory. <br>Note: This Function will reboot system automatically!",
	restore: "Restore",
	
	//upgrade
	upgrade_tip: "Please click button below to select Upgrade File and then perform upgrade",
	upgrade:	"upgrade",
	upgrade_system:	"upgrade system",
	upgrade_wait:	"upgrading now, please wait for a while...",
	wait_reboot:	"System is upgrading now, please wait for system reboot...",
	file_error:		"file error!",
	start_upload:	"start upload",
	stop_upload:	"upload success",
	fail_upload:	"upload failed",
	writing_firmware:	"Writing firmware now...",
	upgrade_success:	"Upgrade success, please refresh this page after 10 seconds",
	
	
	//device information
	dev_name:	"Device Name",
	dev_model:	"Device Model",
	hw_ver:		"Hardware Version",
	sw_ver:		"Software Version",
	rel_time:	"Release Time",
	alarm_num:	"Alarm Number",
	sd_num:	"SD Number",
	
	//2013-02-18
	display_net_id_on_screen:"Display Net-ID on screen",
	
	//-----------------------------
	end:	"end"
};
