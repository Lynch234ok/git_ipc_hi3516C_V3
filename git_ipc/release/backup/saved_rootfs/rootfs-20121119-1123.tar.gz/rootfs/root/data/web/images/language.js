// JavaScript Document
//标点符号
var colon    = "：";
var period   = "。";
var comma    = "，";
var blank    = "&nbsp;";
var exclamation = "！";

//设备信息
var str_devname    = "设备名称";
var str_devtype    = "设备类型";
var str_netstat    = "网络连接状态";
var str_connnum    = "用户连接数";
var str_softver    = "软件版本";
var str_macaddr    = "Mac 地址";
var str_ipaddr     = "IP 地址";
var str_submask    = "子网掩码";
var str_gateway    = "网关";
var str_1stdns     = "首选 DNS";
var str_2nddns     = "备用 DNS";
var str_sysstart   = "系统开始运行时间";
var str_sdstat     = "SD卡状态";
var str_connwireless = "无线连接";
var str_connwired    = "有线连接";
var str_dnsset     = "DNS 设置";
var str_manualdns  = "手动设置DNS";
var str_autodns    = "自动设置DNS";
var str_httpport   = "HTTP 端口";
var str_rtspport   = "RTSP 端口";
var str_rtspauth   = "RTSP权限校验";

//云台设置
var str_addrcode   = "地址码";
var str_protocol   = "协议"; 
var str_portset    = "端口设置";
var str_485portset = 485 + str_portset;
var str_baudrate   = "波特率";
var str_databit    = "数据位";
var str_stopbit    = "停止位";
var str_check      = "校验";
var str_none       = "无";
var str_oddcheck   = "奇校验";
var str_evencheck  = "偶校验";

//FTP 
var str_pasvmode   = "被动模式";

//服务器设置
var str_server     = "服务器";
var str_port       = "端口";
var str_username   = "用户名";
var str_password   = "密码";
var str_repassword = "确认密码";
var str_auth       = "验证";

//email 设置
var str_emailset   = "E-mail 设置";
var str_smtpserv   = "SMTP 服务器：";
var str_sendto     = "接收地址";
var str_emailaddr  = "电邮地址"
var str_sendaddr   = "发件地址";
var str_subject    = "主题";
var str_info       = "信息";
var str_max127c    = "最多可以输入127个字符";

//自动抓拍
var str_timeint    = "时间间隔";
var str_sendemail  = "发送E-mail";
var str_savepic    = "保存图片到SD卡";

//外置报警
var str_offenon    = "常开";
var str_offenoff   = "常闭";
var str_alarmex    = "外置报警输入";
var str_alarmimode = "外置报警模式";

//音频设置
var str_audioset   = "音频设置";
var str_collecta   = "采集音频";
var str_auformat   = "音频格式";
var str_audioin    = "音频输入";
var str_inoption   = "输入选项";
var str_aumicin    = "麦克输入";
var str_aulinein   = "线性输入";

//时间设置
var str_timenow    = "当前日期时间";
var str_change     = "更改";
var str_manualset  = "手动设置";
var str_date       = "日期";
var str_time       = "时间";
var str_dateformat = "(年-月-日)";
var str_timeformat = "(时：分：秒)";
var str_daterange  = "(1971-01-01 ~ 2036-12-31)";
var str_syncfrompc = "同步到PC时间";
var str_pctime     = "PC 时间";
var str_ntserver   = "网络时间服务器";
var str_ntpserver  = "NTP服务器";
var str_synctime   = "同步间隔";
var str_hour       = "小时";
var str_keeptmset  = "保持当前设置";
var str_timezone   = "时区";
var str_autotime   = "自动调节时间";

//视频设置
var str_videoset   = "视频设置";
var str_videomode  = "视频制式";
var str_resolution = "清晰度";
var str_streamrate = "码率";
var str_framerate  = "帧率";
var str_framegap   = "主帧间隔";
var str_vcodectrl  = "视频编码控制";
var str_fixedcr    = "固定码率";
var str_variablecr = "可变码率";
var str_vcodequa   = "视频编码质量";
var str_osdopt     = "叠加选项";
var str_osdtime    = "叠加时间";
var str_osdname    = "叠加名称";
var str_name       = "名称";

//平台设置
var str_plcon      = "平台连接";
var str_puidnum    = "PUID号";
var str_asp        = "接入服务器端口";
var str_asa        = "接入服务器地址";
var str_fsp        = "转发服务器端口";
var str_fsa        = "转发服务器地址";
var str_gpsi       = "GPS信息传输间隔";
var str_msec       = "(毫秒)";
var str_loginid    = "登录ID";
var str_loginpass  = "登录密码";
var str_serverport = "服务器端口";
var str_serveraddr = "服务器地址";
var str_timeout    = "超时时间";
var str_constate   = "连接状态";
var str_devnum     = "设备号";
var str_atransfer  = "音频传输";
var str_alarmtrans = "报警信息传输";

//报警联动
var str_emailalarm = "E-mail 报警";
var str_sendpic    = "发送图片";
var str_saverecftp = "保存视频到FTP服务器";
var str_relayout   = "继电器输出";
var str_savevideo  = "保存视频到SD卡";
var str_ftpservset = "FTP服务器设置";

//网络设置
var str_manualip   = "手动设置IP";
var str_autoip     = "自动获取IP";
var str_lnset      = "局域网设置";
var str_ipget      = "IP 获取";
var str_internetip = "互联网IP地址";
var str_netip      = "互联网IP地址";
var str_proddnsset = "厂商动态域名设置";
var str_hostname   = "主机名";
var str_3thdnsset  = "第三方动态域名设置";
var str_servprov   = "服务商";
var str_autoupnp   = "UPnP自动端口映射";
var str_wlcheck    = "检查无线设置";
var str_wlsuccess  = "连接成功，无线设置正确。";
var str_applywl    = "请点击“应用”保存无线设置。";
var str_wlfailed   = "连接失败，请检查无线设置。";

//调度
var str_weekmode     = "整周模式";
var str_weekendmode  = "工作日休息日模式";
var str_alltimemode  = "所有时间模式";
var str_week         = "星期";
var str_begintime    = "开始时间";
var str_endtime      = "结束时间";
var str_workday      = "工作日";
var str_freeday      = "休息日";
var str_sunday       = "星期日";
var str_monday       = "星期一";
var str_tuesday      = "星期二";
var str_wednesday    = "星期三";
var str_thursday     = "星期四";
var str_friday       = "星期五";
var str_saturday     = "星期六";

//导航
var str_rtview   = "实时监看";
var str_config   = "参数设置";
var str_avargs   = "音视频参数";
var str_videoa   = "视频参数";
var str_imagea   = "图像参数";
var str_audioa   = "音频参数";
var str_netset   = "网络设置";
var str_wlset    = "无线设置";
var str_ddnsset  = "远程访问设置";
var str_plset    = "平台设置";
var str_alarmset = "报警设置";
var str_alarmin  = "外置报警";
var str_mdset    = "移动侦测";
var str_alaction = "报警联动";
var str_altime   = "报警时间";
var str_advset   = "高级设置";
var str_userset  = "用户管理";
var str_timesnap = "定时抓拍";
var str_email    = "电子邮件";
var str_ftpset   = "FTP设置";
var str_ptzset   = "云台设置";
var str_sysset   = "系统设置";
var str_timeset  = "时间设置";
var str_initset  = "初始设置";
var str_devinfo  = "设备信息";

//sd操作
var str_sdview   = "浏览SD卡";
var str_sdfat32  = "用FAT32格式化SD卡";
var str_sdstop   = "停止SD卡";

//sd状态
var str_havesd     = "有卡";
var str_nothavesd  = "无卡";
var str_freespace  = "可用空间"
var str_totalspace = "容量" 

//系统备份升级
var str_reboot     = "重新启动系统";
var str_recoverdef = "恢复出厂默认值";
var str_backup     = "备份配置数据";
var str_recoverbak = "恢复配置数据";
var str_upgradesys = "系统升级";

//按钮字符串
var str_btn_reboot     = "&nbsp;重启&nbsp;";
var str_btn_save       = "&nbsp;保存&nbsp;";
var str_btn_confirm    = "&nbsp;确定&nbsp;";
var str_btn_query      = "&nbsp;查询&nbsp;";
var str_btn_advanced   = "&nbsp;高级&nbsp;";
var str_btn_recoverdef = "恢复出厂设置";
var str_btn_apply      = "&nbsp;应&nbsp;用&nbsp;";
var str_btn_cancel     = "&nbsp;取&nbsp;消&nbsp;";
var str_btn_clear      = "&nbsp;清&nbsp;除&nbsp;";
var str_btn_default    = "&nbsp;默&nbsp;认&nbsp;";
var str_btn_search     = "&nbsp;搜&nbsp;索&nbsp;";
var str_btn_check      = "&nbsp;检&nbsp;查&nbsp;";
var str_btn_close      = "&nbsp;关&nbsp;闭&nbsp;";
var str_btn_refresh    = "&nbsp;刷&nbsp;新&nbsp;";

//提示
var str_note_upgrade       = "设备正在升级，请不要切断电源。";
var str_note_upgradeok     = "系统升级成功！";
var str_note_needreset     = "注意：需要重新启动机器，该设置才生效！";
var str_note_needreset1    = "注意：修改设置后，请重启设备。";
var str_note_needreset2    = "(注意：修改语言设置后，请重启设备。)";
var str_note_astreamnote   = "(注意：手机浏览使用此码流)";
var str_note_wlsetting     = "正在检查无线设置，请等待大约30秒。";
var str_note_inputpath     = "请输入文件路径";
var str_note_inputipaddr   = "请输入IP地址";
var str_note_inputsubmask  = "请输入子网掩码";
var str_note_inputgateway  = "请输入网关";
var str_note_inputhostname = "请输入主机名";
var str_note_inputusername = "请输入用户名";
var str_note_inputpassword = "请输入密码";
var str_note_inputport     = "请输入端口";
var str_note_inputservaddr = "请输入服务器地址";
var str_note_inputservname = "请输入服务器名";
var str_note_inputemail    = "请输入E-mail地址";
var str_note_inputsendaddr = "请输入发件地址";
var str_note_inputasp      = "请输入接入服务器端口";
var str_note_inputasa      = "请输入接入服务器地址";
var str_note_inputfsp      = "请输入转发服务器端口";
var str_note_inputfsa      = "请输入转发服务器地址";
var str_note_inputtimeout  = "请输入超时时间";
var str_note_inputgpsi     = "请输入GPS信息发送间隔时间";
var str_note_noinpublicip  = "设备未接入互联网，无法查询公网IP地址";
var str_note_internetipis  = "互联网IP地址为";
var str_note_vcodequa      = "(值越小，图像质量越好，码流控制幅度越大)";
var str_note_mbsize        = "手机图片分辨率为QVGA";
var str_note_mdoff         = "当主码流分辨率为QVGA或UXGA时，移动检测自动关闭。";
var str_note_maxframerate  = "帧率不能大于25";
var str_note_atransfer     = "(开启音频传输前，请先进入音视频设置页面，设置次码流音频为开启，AMR格式)";
var str_note_ipportchange  = "IP地址或者端口已经被改变，请重新连接！";
var str_note_rhportsame    = "http端口 和 rtsp端口使用相同的端口"
var str_note_inputdate     = "请输入日期";
var str_note_inputtime     = "请输入时间";
var str_note_routemode     = "(如果有无线路由器，请选择路由模式)";
var str_note_inputascii    = "请输入ASCII码字符(字符数是5 或者 13 )";
var str_note_inputascii2   = "请输入ASCII码字符(字符数是8 至 63 )";
var str_note_inputhex      = "请输入16进制数 (长度为 10 或者 26 )";
var str_note_inputssid     = "请输入SSID";
var str_note_inputkey      = "请输入密钥";
var str_note_inputrekey    = "请输入确认密钥";
var str_note_nosupportp2p  = "WPA/WPA2不支持点对点模式";
var str_note_turnoffmd     = "视频分辨率是QVGA或UXGA，移动检测被关闭";
var str_note_autoreboot    = "将自动重启网络摄像机";


//错误提示
var str_err_invaildc   = "包含了无效字符";
var str_err_invaildc2  = "包含了无效字符。( ,:,&,=,\",\\\,\/)";
var str_err_username   = "用户名错误";
var str_err_hostname   = "主机名错误";
var str_err_servname   = "服务器错误";
var str_err_password   = "密码错误";
var str_err_port       = "端口错误";
var str_err_userinfo   = "用户信息错误，请重新输入";
var str_err_servbusy   = "服务器忙，请稍候访问";
var str_err_addrcode   = "地址码超出范围";
var str_err_port       = "端口错误"
var str_err_servaddr   = "服务器地址错误";
var str_err_smptserv   = "SMTP服务器输入错误";
var str_err_emailaddr  = "无效的email地址";
var str_err_tooshort   = "长度不够";
var str_err_noat       = "没有包含@字符";
var str_err_addr1      = "发送到地址1错误";
var str_err_addr2      = "发送到地址2错误";
var str_err_addr3      = "发送到地址3错误";
var str_err_sendaddr   = "发件地址错误";
var str_err_subject    = "主题错误";
var str_err_info       = "信息错误";
var str_err_snapint    = "时间间隔范围为1分钟至1440分钟";
var str_err_pwdconfirm = "确认密码输入错误。";
var str_err_framegap   = "主帧间隔超出范围（2-150），请重新设置";
var str_err_osdname    = "中文名称输入不能超过9个, 英文不能超过18个";
var str_err_noname     = "名称不能为空。";
var str_err_puid       = "PUID号输入错误";
var str_err_asp        = "接入服务器端口错误";
var str_err_asa        = "接入服务器地址错误";
var str_err_fsp        = "转发服务器端口错误";
var str_err_fsa        = "转发服务器地址错误";
var str_err_username   = "用户名错误";
var str_err_timeout    = "超时时间输入错误";
var str_err_tooutrange = "超时时间超出范围。";
var str_err_devnum     = "设备号错误";
var str_err_servaddr   = "服务器地址错误";
var str_err_input      = " 输入错误！\n\n";
var str_err_addrrange1 = "无效的地址,第一个数的";
var str_err_addrlast   = "无效的地址,最后一个数的"
var str_err_addr       = "无效的地址";
var str_err_value      = "无效值";
var str_err_pctime     = "您的PC时间不正确，请输入范围在 1970-01-01 至 2037-12-31";
var str_err_dateformat = "无效的日期格式";
var str_err_dfinput    = "应输入 yyyy-mm-dd";
var str_err_reinputd   = "日期无效，请重新输入 ";
var str_err_invaildtmf = "无效的时间格式";
var str_err_timeformat = "时间格式是 时：分：秒";
var str_err_imvaildtm  = "无效时间";
var str_err_key        = "密钥长度错误.16进制为10 或者 26; ASCII码为5 或者 13";
var str_err_ssid       = "SSID错误，请输入有效字符";
var str_err_rekey      = "确认密钥输入不正确";
var str_err_ssid       = "ssid 错误,包含了无效字符";

var str_bps32_2048 = "码率值超出范围（32-2048 kbps)，请重新设置";
var str_bps32_512  = "码率值超出范围（32-512 kbps)，请重新设置";
var str_bps32_256  = "码率值超出范围（32-256 kbps)，请重新设置";

//范围提示
var str_1_65536 = "范围1-65535";
var str_0_255   = "范围应是0到255";
var str_1_255   = "范围应是1到255";
var str_0_254   = "数值范围应是0到254";
var str_1_254   = "数值范围应是1到254"
var str_80or1024_49151 = "(80 或1024~49151)";
var str_daterange  = "日期范围是 1971-01-01 至 2037-12-31, 请重新输入 ";
var str_drange  = "(1971-01-01 ~ 2036-12-31)";

//没有插件
var str_noins0 = "警告信息显示如下：";
var str_noins1 = "1. 您的电脑没有安装浏览视频控件。";
var str_noins2 = "2. 您已经安装控件但版本不是最新，请重新安装控件。";
var str_noins3 = "请点击";
var str_noins4 = "下载控件";
var str_noins5 = "然后点击";
var str_noins6 = "运行";
var str_noins7 = "安装控件，重新刷新网页，浏览视频。";

//常用字符串
var str_readonly  = "只读";
var str_rate      = "速度";
var str_auto      = "自动";
var str_view      = "监看";
var str_minute    = "分钟";
var str_1ststream = "主码流";
var str_2ndstream = "次码流";
var str_on        = "开启";
var str_off       = "关闭";
var str_online    = "在线";
var str_offline   = "下线";
var str_sec       = "秒";
var str_language  = "语言";
var str_ch        = "中文";
var str_en        = "英文";
var str_add       = "加入";
var str_encrypt   = "加密方式";
var str_authen    = "认证";
var str_connetm   = "连接模式";
var str_channel   = "通道";
var str_confirm   = "确定"; 


//时区
var str_GMT12S  = "(GMT-12:00) 日界线西";
var str_GMT11S  = "(GMT-11:00) 中途岛，萨摩亚群岛";
var str_GMT10S  = "(GMT-10:00) 夏威夷";
var str_GMT09S  = "(GMT-09:00) 阿拉斯加";
var str_GMT08S  = "(GMT-08:00) 太平洋时间（美国和加拿大）";
var str_GMT07S0 = "(GMT-07:00) 山地时间（美国和加拿大）";
var str_GMT07S1 = "(GMT-07:00) 奇瓦瓦，拉巴斯，马萨特兰";
var str_GMT07S2 = "(GMT-07:00) 亚利桑那";
var str_GMT06S0 = "(GMT-06:00) 萨斯喀彻温";
var str_GMT06S1 = "(GMT-06:00) 瓜达拉哈拉，墨西哥城，蒙特雷";
var str_GMT06S2 = "(GMT-06:00) 中部时间 (美国和加拿大)";
var str_GMT06S3 = "(GMT-06:00) 中美洲";
var str_GMT05S0 = "(GMT-05:00) 印地安那州 (东部)";
var str_GMT05S1 = "(GMT-05:00) 东部时间 (美国和加拿大)";
var str_GMT05S2 = "(GMT-05:00) 波哥大，利马，里奥布朗库";
var str_GMT04S0 = "(GMT-04:00) 圣地亚哥";
var str_GMT04S1 = "(GMT-04:00) 拉巴斯";
var str_GMT04S2 = "(GMT-04:00) 大西洋时间 (加拿大)";
var str_GMT03S0 = "(GMT-03:30) 纽芬兰"; 
var str_GMT03S1 = "(GMT-03:00) 格陵兰";
var str_GMT03S2 = "(GMT-03:00) 布宜诺斯艾利斯，乔治敦";
var str_GMT03S3 = "(GMT-03:00) 巴西利亚";
var str_GMT02S  = "(GMT-02:00) 中大西洋";
var str_GMT01S0 = "(GMT-01:00) 佛得角群岛";
var str_GMT01S1 = "(GMT-01:00) 亚速尔群岛";
var str_GMT     = "(GMT) 格林威治标准时间：都柏林，爱丁堡，伦敦，里斯本"; 
var str_GMT00A0 = "(GMT) 卡萨布兰卡，蒙罗维亚，雷克雅未克";
var str_GMT01A0 = "(GMT+01:00) 阿姆斯特丹，柏林，伯尔尼，罗马，斯德哥尔摩，维也纳";
var str_GMT01A1 = "(GMT+01:00) 贝尔格莱德，布拉迪斯拉发，布达佩斯，卢布尔雅那，布拉格";
var str_GMT01A2 = "(GMT+01:00) 布鲁塞尔，哥本哈根，马德里，巴黎";
var str_GMT01A3 = "(GMT+01:00) 萨拉热窝，斯科普里，华沙，萨格勒布";
var str_GMT01A4 = "(GMT+01:00) 西非中部";
var str_GMT02A0 = "(GMT+02:00) 雅典，伊斯坦布尔，明斯克";
var str_GMT02A1 = "(GMT+02:00) 布加勒斯特";
var str_GMT02A2 = "(GMT+02:00) 开罗";
var str_GMT02A3 = "(GMT+02:00) 哈拉雷，比勒陀利亚";
var str_GMT02A4 = "(GMT+02:00) 赫尔辛基，基辅，里加，索非亚，塔林，维尔纽斯";
var str_GMT02A5 = "(GMT+02:00) 耶路撒冷";
var str_GMT03A0 = "(GMT+03:00) 巴格达";
var str_GMT03A1 = "(GMT+03:00) 科威特，利雅得";
var str_GMT03A2 = "(GMT+03:00) 莫斯科，圣彼得堡，伏尔加格勒";
var str_GMT03A3 = "(GMT+03:00) 奈洛比";
var str_GMT03A4 = "(GMT+03:30) 德黑兰";
var str_GMT04A0 = "(GMT+04:00) 阿布扎比，马斯喀特";
var str_GMT04A1 = "(GMT+04:00) 巴库，第比利斯，耶烈万";
var str_GMT04A2 = "(GMT+04:30) 喀布尔";
var str_GMT05A0 = "(GMT+05:00) 叶卡特琳堡";
var str_GMT05A1 = "(GMT+05:00) 伊斯兰堡，卡拉奇，塔什干";
var str_GMT05A2 = "(GMT+05:30) 马德拉斯，加尔各答，孟买，新德里";
var str_GMT05A3 = "(GMT+05:45) 加德满都";
var str_GMT06A0 = "(GMT+06:00) 阿拉木图, 新西伯利亚";
var str_GMT06A1 = "(GMT+06:00) 阿斯塔纳，达卡";
var str_GMT06A2 = "(GMT+06:00) 科伦坡";
var str_GMT06A3 = "(GMT+06:30) 仰光";
var str_GMT07A0 = "(GMT+07:00) 曼谷，河内，雅加达";
var str_GMT07A1 = "(GMT+07:00) 克拉斯诺亚尔斯克";
var str_GMT08A0 = "(GMT+08:00) 北京，重庆，香港特别行政区，乌鲁木齐";
var str_GMT08A1 = "(GMT+08:00) 伊尔库次克，乌兰巴图";
var str_GMT08A2 = "(GMT+08:00) 吉隆坡，新加坡";
var str_GMT08A3 = "(GMT+08:00) 珀斯";
var str_GMT08A4 = "(GMT+08:00) 台北";
var str_GMT09A0 = "(GMT+09:00) 大阪，札幌，东京";
var str_GMT09A1 = "(GMT+09:00) 汉城";
var str_GMT09A2 = "(GMT+09:00) 雅库茨克"; 
var str_GMT09A3 = "(GMT+09:30) 阿德莱德";
var str_GMT10A0 = "(GMT+10:00) 布里斯班";
var str_GMT10A1 = "(GMT+10:00) 堪培拉，墨尔本，悉尼";
var str_GMT10A2 = "(GMT+10:00) 关岛，莫尔兹比港";
var str_GMT10A3 = "(GMT+10:00) 霍巴特";
var str_GMT10A4 = "(GMT+10:00) 符拉迪沃斯托克";
var str_GMT11A0 = "(GMT+11:00) 马伽迪斯琴，所罗门群岛，新喀里多尼亚";
var str_GMT12A0 = "(GMT+12:00) 奥克兰，惠灵顿";
var str_GMT12A1 = "(GMT+12:00) 斐济，堪察加半岛，马绍尔群岛";
var str_GMT13A0 = "(GMT+13:00) 努库阿洛法";

//询问字符串
var str_ask_sdfat32    = "SD卡将被格式化为FAT32文件系统？";
var str_ask_sdstop     = "SD卡将被停止？";
var str_ask_recoverbak = "系统设置将被恢复？";
var str_ask_syspath    = "请输入升级文件路径";
var str_ask_upgradesys = "系统将开始升级？";
var str_ask_reboot     = "系统将重新启动？";
var str_ask_recoverdef = "系统将恢复到出厂设置？";

// display
var str_adjustneff  = "（夜视效果调节）";
var str_nightmode   = "夜视模式";
var str_adjustnl    = "夜视照度调节";
var str_nlight      = "夜视照度";
var str_brightness  = "亮&nbsp;&nbsp;&nbsp;&nbsp;度";
var str_saturation  = "饱和度";
var str_contrast    = "对比度";
var str_hue         = "色&nbsp;&nbsp;&nbsp;&nbsp;度";
var str_shutter     = "快&nbsp;&nbsp;&nbsp;&nbsp;门";
var str_dnt         = "灵敏度";
var str_lumi        = "低照度";
var str_imageset    = "图像设置";
var str_updown      = "上下反转";
var str_leftright   = "左右反转";
var str_sensitivity = "灵敏度";
var str_wdrmode     = "宽动态模式";
var str_window      = "窗口";
var str_safetype    = "安全类型";
var str_encway      = "加密方法"; 
var str_key         = "密钥";
var str_confirmkey  = "确认密钥";
var str_checkwl     = "检查无线设置";

// 无线
var str_wlenable    = "启用无线";
var str_conmode     = "连接模式";
var str_route       = "路由";
var str_p2p         = "点对点";

var str_welcome     = "请选择您要进行的操作：";
var str_pcview      = "电脑观看";
var str_mbview      = "手机观看";
var str_setupsoft   = "安装软件（初次使用）";

// 返回
var str_returnrtv   = "返回预览";

// 云台
var str_presetcall  = "调用";
var str_presetset   = "设置";
var str_zoomin      = "拉近";
var str_zoomout     = "拉远";