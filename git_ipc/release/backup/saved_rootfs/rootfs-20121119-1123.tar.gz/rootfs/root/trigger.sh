#!/bin/sh

#ifconfig eth0 192.168.1.45 up
ifconfig eth0 192.168.1.49 up
ifconfig lo 127.0.0.1 up
route add -net 224.0.0.0 netmask eth0
touch /tmp/resolv.conf
echo "nameserver 8.8.8.8" >> /tmp/resolv.conf
echo "nameserver 168.95.1.1" >> /tmp/resolv.conf
sleep 2

ulimit -c unlimited
echo "1" > /proc/sys/kernel/core_uses_pid
echo "/tmp/%e-%t.core" > /proc/sys/kernel/core_pattern

echo "3000000" > /proc/sys/net/core/rmem_default
echo "3000000" > /proc/sys/net/core/rmem_max

telnetd

# my nfs environment
mount -t nfs -o nolock 192.168.1.41:/root/nfs /root/nfs 
export PATH=$PATH:"/root/nfs/bin"
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:"/root/nfs/lib"

# environment
export DATADIR=/root/data
export FONTDIR=$DATADIR/font
export WEBDIR=$DATADIR/web/
export FLASHMAP=$DATADIR/hi3507_ipcam.ini
export SYSCONF=/dev/mtdblock/3

read -t 1 -n 1 char
if [ "$char" == "n" ]; then
	echo "Application Cancel!"
else
	echo "Application Trigger!"
	insmod /root/bsp/i2cm.ko
	insmod /root/bsp/rtc.ko
#	insmod /root/bsp/watchdog.ko

	hwclock -r

	while [ 1 ]
	do
		/root/app/ipcam_app
	done

fi

