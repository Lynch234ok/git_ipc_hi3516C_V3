//function $(_id){return document.getElementById(_id);}
function getarg()
{
	if(window.location.search != "")
	{
		var allargs = window.location.search.split("?")[1];
		var args = allargs.split("&");
		for(var i=0; i<args.length; i++)
		{
			var arg = args[i].split("=");
			eval('this.'+arg[0]+'="'+arg[1]+'";');
		}
	}
}
function set_sys_cookie(_id, _usr, _pwd, _chn)
{
	var content = "id=" + _id;
	content += "|usr=" + _usr;
	content += "|pwd=" + _pwd;
	content += "|chn=" + _chn;
	document.cookie = escape(content);
}
function get_sys_cookie(_key)
{
	var ret = null;
	var strs = unescape(document.cookie).split("|");
	for(var i = 0; i < strs.length; i++)
	{
		if(strs[i].split("=")[0] == _key)
		{
			ret = strs[i].split("=")[1];
		}
	}
	return ret;
}

function mk_chn_content(_id, _chn)
{
	for(var i = 0; i < _chn; i++)
	{
		$("#" + _id)[0].options.add(new Option(i+1,i));
	}
}

function mk_copyto_content(_id, _chn)
{
	for(var i = 0; i < _chn; i++)
	{
		var jobj = $("#" + _id);
		if(i > 0 && (i % 4) == 0)
		{
			var br = document.createElement("br");
			jobj[0].appendChild(br);
		}
		var chk = document.createElement("input");
		chk.setAttribute("id", "chk_copyto_" + i);
		chk.setAttribute("type", "checkbox");
		chk.setAttribute("value", i);
		jobj[0].appendChild(chk);
		var span = document.createElement("span");
		span.innerHTML = i+1;
		jobj[0].appendChild(span);
	}
}

function get_copyto_value(_id_prefix, _chn)
{
	var ret = 0;
	for(var i = 0; i < _chn; i++)
	{
		if($("#" + _id_prefix + i)[0].checked == true)
		{
			ret += Math.pow(2, i);
		}
	}
	return ret;
}

function loadXMLString(txt)
{
	if (window.DOMParser)
	{
		parser=new DOMParser();
		xmlDoc=parser.parseFromString(txt,"text/xml");
	}
	else // Internet Explorer
	{
		xmlDoc=new ActiveXObject("Microsoft.XMLDOM");
		xmlDoc.async="false";
		xmlDoc.loadXML(txt);
	}
	return xmlDoc;
}

function toXMLString(xmldoc)
{
	var xmlstr;
	if (window.DOMParser)
	{
		var xmlser = new XMLSerializer();
		xmlstr = xmlser.serializeToString(xmldoc);
	}
	else
	{
		xmlstr = xmldoc.xml;
	}
	return xmlstr;
}

function create_http()
{
	http_request = false;  
	if (window.XMLHttpRequest)
	{ // Mozilla, Safari,...  
		http_request = new XMLHttpRequest();  
	}
	else if (window.ActiveXObject) 
	{ // IE  
		try
		{  
			http_request = new ActiveXObject("Msxml2.XMLHTTP");  
		}
		catch (e)
		{
			try
			{  
				http_request = new ActiveXObject("Microsoft.XMLHTTP");  
			}
			catch (e) {}  
		}  
	}  
	return http_request;
}

function get_value_string(_xml_node, attr_name, _html_obj)
{
	if(_xml_node == null || _html_obj == null)
	{
		return;
	}
	if(_xml_node.attributes.getNamedItem(attr_name) != null)
	{
		if(_html_obj.tagName == "SPAN")
		{
			_html_obj.innerHTML = _xml_node.attributes.getNamedItem(attr_name).nodeValue;
		}
		else
		{
			_html_obj.value = _xml_node.attributes.getNamedItem(attr_name).nodeValue;
			_html_obj.olddata = _xml_node.attributes.getNamedItem(attr_name).nodeValue;
		}
	}
}

function get_value_enum(_xml_node, attr_name, _html_obj)
{
	if(_xml_node == null || _html_obj == null)
	{
		return;
	}
	if(_xml_node.attributes.getNamedItem(attr_name) != null)
	{
		_html_obj.selectedIndex = _xml_node.attributes.getNamedItem(attr_name).nodeValue;
		_html_obj.olddata = _xml_node.attributes.getNamedItem(attr_name).nodeValue;
	}
}

function read_value_binand(_html_obj_prefix, _html_obj_count)
{
	var ret = 0;
	if(_html_obj_prefix == "")
	{
		return ret;
	}
	for(var i = 0; i < _html_obj_count; i++)
	{
		if($(_html_obj_prefix + i).checked == true)
		{
			ret += (1 << i);
		}
	}
	return ret;
}

function get_value_bitand(_xml_node, attr_name, _html_obj_prefix, _html_obj_count)
{
	if(_xml_node == null || _html_obj_prefix == "")
	{
		return;
	}
	if(_xml_node.attributes.getNamedItem(attr_name) != null)
	{
		var value = _xml_node.attributes.getNamedItem(attr_name).nodeValue;
		for(var i = 0; i < _html_obj_count; i++)
		{
			$(_html_obj_prefix + i).checked = ((value & (1<<i)) == (1<<i));
		}
	}
}

function get_value_chnindex(_xml_node, attr_name, _html_obj)
{
	if(_xml_node == null || _html_obj == null)
	{
		return;
	}
	if(_xml_node.attributes.getNamedItem(attr_name) != null)
	{
		_html_obj.selectedIndex = _xml_node.attributes.getNamedItem(attr_name).nodeValue;
		_html_obj.olddata = _xml_node.attributes.getNamedItem(attr_name).nodeValue;
	}

	var chks = $("div[name='copyto_" + _xml_node.tagName + "']");
	for(var i = 0; i < chks.length; i++)
	{
		if(i == _xml_node.attributes.getNamedItem(attr_name).nodeValue)
		{
			chks[i].firstChild.checked = true;	
		}
		else
		{
			chks[i].firstChild.checked = false;	
		}
	}
}

function get_value_int(_xml_node, attr_name, _html_obj)
{
	get_value_string(_xml_node, attr_name, _html_obj);
}

function get_value_ip(_xml_node, attr_name, _html_obj)
{
	get_value_string(_xml_node, attr_name, _html_obj);
}

function get_value_mac(_xml_node, attr_name, _html_obj)
{
	get_value_string(_xml_node, attr_name, _html_obj);
}

function get_value_time(_xml_node, attr_name, _html_obj)
{
	get_value_string(_xml_node, attr_name, _html_obj);
}

function get_value_date(_xml_node, attr_name, _html_obj)
{
	get_value_string(_xml_node, attr_name, _html_obj);
}

function show_loading(retry_call)
{
	$("#spn_retry")[0].style.display = "none";
	$("#lxc_alpha")[0].style.display="block";
	$("#a_retry")[0].href = "javascript:" + retry_call;
	dvr_t = setTimeout("$(\"#spn_retry\")[0].style.display = \"block\"", 2000);
}

function hide_loading()
{
	$("#lxc_alpha")[0].style.display="none";
}

function cancel_loading()
{
	if(dvr_ajax)
	{
		dvr_ajax.abort();
		dvr_ajax = null;
	}
}
