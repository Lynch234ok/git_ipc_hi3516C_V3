
CUR_PATH=`dirname $0`

TDE_PATH=$CUR_PATH/hi3511mod
MPP_PATH=$CUR_PATH/hi3511mod
MISC_PATH=$CUR_PATH/hi3511mod

insmod $TDE_PATH/tde.ko
insmod $MPP_PATH/hi3511_base.ko
insmod $MPP_PATH/hi3511_sys.ko
insmod $MPP_PATH/hi3511_viu.ko
insmod $MPP_PATH/hi3511_vou.ko
insmod $MPP_PATH/hi3511_dsu.ko
insmod $MPP_PATH/hi3511_vpp.ko
insmod $MPP_PATH/hi3511_venc.ko
insmod $MPP_PATH/hi3511_group.ko
insmod $MPP_PATH/hi3511_vdec.ko
insmod $MPP_PATH/hi3511_md.ko
insmod $MPP_PATH/hi3511_sio.ko
insmod $MPP_PATH/hi3511_ai.ko
insmod $MPP_PATH/hi3511_ao.ko
insmod $MPP_PATH/hi3511_chnl.ko
insmod $MPP_PATH/hi3511_h264e.ko
insmod $MPP_PATH/hi3511_h264d.ko
insmod $MPP_PATH/hi3511_jpege.ko
insmod $MPP_PATH/hi3511_jpegd.ko

insmod $MISC_PATH/hidmac.ko

insmod $MISC_PATH/mmz.ko mmz=anonymous,0,0xe4800000,56M anony=1
modprobe fb
insmod $MISC_PATH/hifb.ko video="hifb:vram0_size:831488,vram1_size:4096"


modprobe libphy
insmod $MISC_PATH/hiether.ko

