insmod Godshand.ko

insmod vpl_edmc.ko
insmod vpl_dmac.ko
insmod vma_jebe.ko
insmod vma_h4cde.ko
insmod vma_ispe.ko
./sensor.sh
