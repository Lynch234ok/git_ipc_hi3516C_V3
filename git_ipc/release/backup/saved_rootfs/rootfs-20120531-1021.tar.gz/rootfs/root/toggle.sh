#!/bin/sh



ifconfig eth0 192.168.1.45 up
ifconfig lo 127.0.0.1 up

telnetd

mount -t nfs -o nolock 192.168.1.41:/root/nfs /root/nfs 

