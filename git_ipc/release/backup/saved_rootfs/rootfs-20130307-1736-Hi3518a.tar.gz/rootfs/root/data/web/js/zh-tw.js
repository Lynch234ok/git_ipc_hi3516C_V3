
var langstr={
//index page
title : "網絡攝像機",
preview : "預覽",
setup : "設置",
console : "控制台",
record : "錄像",
playback: "回放",
zoom : "焦距",
zoom_in: "減小",
zoom_out: "增大",
full_screen : "全屏",
stream_change: "主次碼流切換",
main_stream : "主碼流",
sub_stream : "次碼流",

helper : "幫助窗體",

//menu
media: "視頻參數",
video: "視頻設置",
image: "圖像設置",
network: "網絡參數",
local: "本地訪問設置",
remote: "遠程訪問設置",
advance_setup: "高級設置",
usermanage: "用戶管理",
system: "系統參數",
time: "時間設置",
initial: "初始化設置",
devinfo: "設備信息",

//save button
save_video: "保存視頻設置",
save_image: "保存圖像設置",
save_local: "保存地址訪問設置",
save_remote: "保存遠程訪問設置",
save_time: "保存時間設置",
save_init: "保存初使化設置",
//common
ok: "確定",
cancel: "取消",
save: "保存",
save_setup: "正在保存設置",
save_refresh: "保存設置成功，請刷新頁面。",
save_preview: "生成預覽成功，請保存。",
format_wrong: "格式不正確，正確的頁面應該形如：",
port_wrong: "端口不正確，應該為一個整數。",
delete_confirm: "你確定要刪除嗎？",
delete_fail: "刪除失敗！",
add_fail: "添加失敗！",
old_pwd_wrong: "舊密碼錯誤！",
confirm_pwd_wrong: "兩次輸入的密碼不一致！",
modify_pwd_fail: "修改密碼失敗！",
delete: "刪除",
close: "關閉",
reboot_refresh: "正在重啟，請稍後重新刷新這個頁面。",
sync_time_now: "正在進行時間同步。。。",
sync_refresh: "同步成功，請重新刷新頁面。",

//video
shutter: "快門",
m_stream: "主碼流",
s_stream1: "子碼流 1",
s_stream2: "子碼流 2",
resolution: "分辨率",
bps: "碼率",
fix: "固定",
volatile: "可變",
fps: "幀率",
quality: "編碼質量",
best: "最好",
good: "好",
normal: "普通",
bad: "較差",
worst: "差",

//image
hue: "色度",
contrast: "對比度",
brightness: "亮度",
saturation: "飽和度",

/////////Network
// local
mac: "網卡地址",
dhcp: "DHCP 狀態",
open: "開啟",
close: "關閉",
esee: "易視網狀態",
ip: "IP 地址",
gateway: "網關",
netmask: "子網掩碼",
dns0: "首選 DNS",
dns1: "備用 DNS",
port: "端口",
// remote-ddns
ddns_set: "DDNS 設置",
ddns: "DDNS 狀態",
server: "DDNS服務商",
domain: "域名",
user: "用戶名",
password: "密碼",
// remote-pppoe
pppoe_set: "PPPoE 設置",
pppoe: "PPPoE 狀態",

//////advanced setup
//user management
username: "用戶名",
authority: "權限",
operation: "操作",
update_list : "更新列表",
adduser: "添加用戶",
changepwd: "修改密碼",
oldpwd: "舊密碼",
newpwd: "新密碼",
confirmpwd: "確認密碼",

//////system setup
//time
dev_time: "設備時間",
date_frt: "日期格式",
date_frt1: "YMD: xxxx xx xx",
date_frt2: "MDY: xx xx xxxx",
date_frt3: "DMY: xx xx xxxx",
date_del: "日期分隔符",
date_del1: "xxxx-xx-xx",
date_del2: "xxxx/xx/xx",
date_del3: "xxxx.xx.xx",
timezone:	"時區",
daylightt: "夏時制",
manual_set: "手動設置",
date: "日期",
time: "時間",
sync_pc_time: "本地時間設置",
pc_time: "當前電腦時間",
sync: "同步",
sync_ntp_time: "NTP服務同步設置",
ntp: "NTP 狀態",
ntp_server: "NTP 服務商",

//reboot
reboot_tip: "按下面的按鈕開始重啟設備",
reboot: "重啟",

//restore factory setup
restore_tip: "按下面的按鈕恢復出廠設置",
restore: "恢復出廠設置",

//upgrade
upgrade_tip: "按下面的按鈕選擇升級文件,併升級",
upgrade: "升級",
upgrade_system: "升級系統",
upgrade_wait: "升級中，請耐心等待！",
wait_reboot: "系統正在升級，請等待系統重啟！",
file_error: "文件錯誤！",
start_upload: "開始上傳。",
stop_upload: "上傳成功。",
fail_upload: "上傳失敗！",
writing_firmware: "正在燒寫系統。。。",
upgrade_success: "升級成功，請大約10秒後重新刷新頁面！",

//device information
dev_name: "設備名",
dev_model: "設備型號",
hw_ver: "硬件版本",
sw_ver: "軟件版本",
rel_time: "發布時間",
alarm_num: "報警路數",
sd_num: "SD 卡數",

//2013-02-18
display_net_id_on_screen:"是否在屏幕上顯示易視網ID號",

//-----------------------------
end: "end"
};
