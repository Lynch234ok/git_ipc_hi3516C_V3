//cookie
//声明配置值
var config = {};
//版本号
//全局
config.stage = {};
//开启Debug
//启用js动画
//系统
//定义html地址
//影配置

var hue=0;
var saturation=0;
var brightness=0;
var contrast=0;

$(window).ready(function(){
//	alert("窗体加载完毕，开始绑定函数");
	//预热舞台
	readyStage();

	//重载舞台
	stageResize();

	//插件启动
	var ip=document.location.host;
	var port=document.location.port;
	if(port=="")	//80
	{
	port=80;
	}
	else{
	var i=document.location.host.indexOf(":");
	ip=document.location.host.substring(0,i);
	}

	//开启本地时间
	setTimeout("renewtime()",10);

}).resize(function(){
	stageResize();
});

//舞台自适应
function stageResize(){

	$('#stage').css({
		height: $(window).height() - $('#logo').height()
	});
/*
	$('#area-stage-right').css({
		width: $('#stage').width() - $('#area-stage-help').width(),
		height: $('#stage').width().height - parseInt($('div.inner').css('margin-top'))*2
	});
*/	
};


//预热舞台
function readyStage(){
/*
	//窗体标题栏动作
	$('div.title-window').click(function(){
		$(this).parents('div.window').toggleClass('windowMin');
		$(this).parents('div.window').children(".mainer").toggle(130);
	});
*/
	//预览/配置标签
	$('#logo-config').children('span').eq(0).css({"width":"100px","height":"52px","line-height":"52px","margin-top":"3px","color":"#666666","font-size":"26px","border-bottom":"0"});			
	$('.logo-inactive').click(function(){
		$('#logo-config').children().css({"width":"58px","height":"40px","line-height":"40px","margin-top":"15px","color":"#ccc","font-size":"20px","border-bottom":"1px solid #CCC"});
		$(this).css({"width":"100px","height":"52px","line-height":"52px","margin-top":"3px","color":"#666666","font-size":"26px","border-bottom":"0"});
	});
	//切换次级菜单
	$('a.btn-left').click(function(e){
		var btn = $(this);
		var currentid = btn.attr("id");
		//获取链接
		$('a.btn-left-active').removeClass('btn-left-active')
		btn.addClass('btn-left-active');
//		showInfo('bingo!');
		//特殊标签
		$('#area-stage-left').children('span').addClass('hidden');
		$("."+currentid).removeClass('hidden');
//		hideInfo();
		bindAction();
	});
	//对应窗体显示
	$('li a').click(function(){
		var dest = $(this);
		var destmark = dest.attr("id");
		$("ul li").removeClass('submenu_current');
		dest.parent().addClass('submenu_current');
		$('#area-stage-right').children('div').addClass('hidden');
		$("."+destmark).removeClass('hidden');
		
		if(destmark == "video")
		{
			video_load_content();
		}
		else if(destmark == "image")
		{
			image_load_content();
		}
		else if(destmark == "local-network")
		{
			network_load_content();
		}
		else if(destmark == "remote-network")
		{
			remote_load_content();
		}
		else if(destmark == "time")
		{
			time_load_content();
		}
		else if(destmark == "devinfo")
		{
			devinfo_load_content();
		}
		else if(destmark == "user-management")
		{
			user_management_load_content();
		}
	});
	//表格上色&排版
	$(".table-common").find("tr:even").children('td').css("background-color","#F1F1F1");
	$(".marker").css("padding-left","5px");
	//CAM HOVER
	$('#ptz-controller-cam').hover(function(){$(this).css("background-image","url(images/ptz-controller-cam-hover.png)");},function(){$(this).css("background-image","url(images/ptz-controller-cam.png)");});
	//PTZ EXPANSION
	$('#consoler').mouseenter(function()
	{
		$('#ptz-controller-up').stop(true,true).css({"opacity":0 , "top":"48px"}).animate({"opacity":1 , "top":"10px"},200);
		$('#ptz-controller-left').stop(true,true).css({"opacity":0 , "left":"48px"}).animate({"opacity":1 , "left":"10px"},200);
		$('#ptz-controller-right').stop(true,true).css({"opacity":0 , "left":"48px"}).animate({"opacity":1 , "left":"102px"},200);
		$('#ptz-controller-down').stop(true,true).css({"opacity":0 , "top":"48px"}).animate({"opacity":1 , "top":"102px"},200);
	});
	//PTZ PACK
	$('#consoler').mouseleave(function()
	{
		$('#ptz-controller-up').animate({"opacity":0 , "top":"-48px"},200,function(){$(this).css({"top":"48px"});});	
		$('#ptz-controller-left').animate({"opacity":0 , "left":"-48px"},200,function(){$(this).css({"left":"48px"});});	
		$('#ptz-controller-right').animate({"opacity":0 , "left":"144px"},200,function(){$(this).css({"left":"48px"});});	
		$('#ptz-controller-down').animate({"opacity":0 , "top":"144px"},200,function(){$(this).css({"top":"48px"});});	
	});
	//PTZ ARROW HOVER
	$('#ptz-controller-up').hover(function(){$(this).css("background-image","url(images/ptz-controller-up-hover.png)");},function(){$(this).css("background-image","url(images/ptz-controller-up.png)");});
	$('#ptz-controller-left').hover(function(){$(this).css("background-image","url(images/ptz-controller-left-hover.png)");},function(){$(this).css("background-image","url(images/ptz-controller-left.png)");});
	$('#ptz-controller-right').hover(function(){$(this).css("background-image","url(images/ptz-controller-right-hover.png)");},function(){$(this).css("background-image","url(images/ptz-controller-right.png)");});
	$('#ptz-controller-down').hover(function(){$(this).css("background-image","url(images/ptz-controller-down-hover.png)");},function(){$(this).css("background-image","url(images/ptz-controller-down.png)");});
	
	//Zoom in/out
	$('#zoom-in').hover(function(){$(this).css("background-image","url(images/zoom-in-hover.png)");},function(){$(this).css("background-image","url(images/zoom-in.png)");});
	$('#zoom-out').hover(function(){$(this).css("background-image","url(images/zoom-out-hover.png)");},function(){$(this).css("background-image","url(images/zoom-out.png)");});

	//Others
	$(".w_imagebtn").eq(0).hover(function(){$(this).css("background-image","url(images/record-hover.png)");},function(){$(this).css("background-image","url(images/record.png)");});
	$(".w_imagebtn").eq(1).hover(function(){$(this).css("background-image","url(images/playback-hover.png)");},function(){$(this).css("background-image","url(images/playback.png)");});
	$(".w_imagebtn").eq(2).hover(function(){$(this).css("background-image","url(images/fullscreen-hover.png)");},function(){$(this).css("background-image","url(images/fullscreen.png)");});
	$(".w_imagebtn").eq(3).hover(function(){$(this).css("background-image","url(images/stream-change-hover.png)");},function(){$(this).css("background-image","url(images/stream-change.png)");});

	var url = self.location.href.match(/\=.*/);
};

//绑定动作
function bindAction(){	
	//选择框动作	
		//判断是否是默认值		
		//点击动作		
			//切换状态
			$(this).parent().toggleClass('changed');
			//更改标题栏		
};


//获取一个随机数值
function setMid() {
	//获取暂存索引
	var mid = Math.random().toString().replace(/\./, '');
	//返回数值
	return mid;
};

//将Json转化为字符串
function parseString(para){
	var mimikoString = JSON && typeof(para) != 'string' ? JSON.stringify(para) : para;
	return mimikoString;
};

//将一个字符串转换为Json
function parseJson(para){
	var mimikoJson = typeof(para) != 'object' ? $.parseJSON(para) : para;
	return mimikoJson;
};

//显示信息
function showInfo(para, callback){
	if(!$('#txtLoadinInfo').length){
		$('#message_here').append('<span id="txtLoadinInfo">' + para +'</span>');
	}else
	{
		$('#txtLoadinInfo')[0].innerText = para;
	};
	$('#txtLoadinInfo').stop(false, true).css({
		opacity:0
	}).animate({
		opacity:1
	},250, function(){
		if ($.isFunction(callback)) {
			callback();
		};
	});
};

//隐藏信息
function hideInfo(para){
	window.setTimeout(function(){
		$('#txtLoadinInfo').stop(false, true).animate({
			opacity:0
		}, 250, function(){
			$(this).remove();
		});
	}, para);
};

//Azrael的试管
//本地时间函数
var yy,mm,dd,hh,mi,ss;
function renewtime()
{
    var myDate = new Date();
	yy=myDate.getFullYear().toString();
	if (yy.length<4)
	{
		var i = 4-yy.length;
		for (var j = 0; j < i; j++)
		{
			yy = "0" + yy;
		}
	}
	mm=(myDate.getMonth()+parseInt(1)).toString();
	mm=(mm.length==1)?("0"+mm):mm
	dd=myDate.getDate().toString();
	dd=(dd.length==1)?("0"+dd):dd
	hh=myDate.getHours().toString();
	hh=(hh.length==1)?("0"+hh):hh
	mi=myDate.getMinutes().toString();
	mi=(mi.length==1)?("0"+mi):mi
	ss=myDate.getSeconds().toString();
	ss=(ss.length==1)?("0"+ss):ss
	$('#time_pc')[0].value = yy + "-" + mm + "-" + dd + "  " + hh + ":" + mi + ":" + ss;
	setTimeout("renewtime()",10);
}
//主次码流预览标签
var stream_state = 1;
function preview_stream()
{
	if (stream_state == 0)
	{
		$('.window-preview').children('.title-window')[0].innerHTML = langstr.main_stream;
		stream_state = 1;
		streamchange(stream_state);
	}else if (stream_state == 1)
	{
		$('.window-preview').children('.title-window')[0].innerHTML = langstr.sub_stream;
		stream_state = 0;
		streamchange(stream_state);
	}
}
//升级界面动画
function showBg()
{  
//	var bh = $("body").height();  
//	var bw = $("body").width();  
//	$("#maskbg").css({ height:bh, width:bw, display:"block" });  
	$("#maskbg").fadeIn(200);
	$("#update_process").fadeIn(400);  
}   
function closeBg() {  
	$("#maskbg,#update_process").fadeOut();  
}  

//预览配置切换函数
function cslshine(tips)
{
	switch(tips)
	{
		case 0: 
			$('#consoler').show(); 
			$('#area-stage-left').hide();
			$('#area-stage-right').hide();
			$('#area-stage-help').hide();
			$('.window-preview').show();
//			if (navigator.appName.indexOf("Microsoft Internet Explorer") != -1)
//			{
				load1();
//			}
			break;
		case 1: 
			$('#consoler').hide(); 
			$('#area-stage-left').show(); 
			$('.window-preview').hide();
			$('#area-stage-right').show();
			$('#area-stage-help').show();
				$('a.btn-left-active').removeClass('btn-left-active')
				$("#video-image").addClass('btn-left-active');
				$('#area-stage-left').children('span').addClass('hidden');
				$(".video-image").removeClass('hidden');
				$("ul li").removeClass('submenu_current');
				$("#video").parent().addClass('submenu_current');
				setTimeout("$('#area-stage-right').children('div').addClass('hidden');$('.video').removeClass('hidden');",50);	
				setTimeout("video_load_content()",55);			
			break;
		default: 
			$('#consoler').hide(); 
			$('#area-stage-left').show();
	}
}
