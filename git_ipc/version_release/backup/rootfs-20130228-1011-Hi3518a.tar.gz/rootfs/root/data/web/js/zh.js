
var langstr={
	//index page
	title : "网络摄像机",
	preview :	"预览",
	setup :		"设置",
	console :	"控制台",
	record :	"录像",
	playback:	"回放",
	zoom :		"焦距",
	zoom_in:	"减小",
	zoom_out:	"增大",
	full_screen :	"全屏",
	stream_change:	"主次码流切换",
	main_stream :	"主码流",
	sub_stream :	"次码流",	
	
	helper :	"帮助窗体",
	
	//menu
	media:		"视频参数",
		video:		"视频设置",
		image:		"图像设置",
	network:	"网络参数",
		local:		"本地访问设置",
		remote:		"远程访问设置",
	system:		"系统参数",
		time:		"时间设置",
		initial:	"初始化设置",
		devinfo:	"设备信息",
	
	//save button
	save_video:	"保存视频设置",
	save_image:	"保存图像设置",
	save_local: "保存地址访问设置",
	save_remote: "保存远程访问设置",
	save_time: "保存时间设置",
	save_init: "保存初使化设置",
	//common
	ok:		"确定",
	cancel:	"取消",	
	
	//video 
	shutter:	"快门",
	m_stream:	"主码流",
	s_stream1:	"子码流 1",	
	s_stream2:	"子码流 2",
	resolution:	"分辨率",
	bps:	"码率",
		fix:	"固定",
		volatile:	"可变",	
	fps:	"帧率",
	quality:	"编码质量",
		best:	"最好",
		good:	"好",
		normal:	"普通",
		bad:	"较差",
		worst:	"差",
		
	//image
	hue:	"色度",
	contrast:	"对比度",
	brightness:	"亮度",
	saturation:	"饱和度",
	
	/////////Network
	// local
	mac:	"网卡地址",
	dhcp:	"DHCP 状态",
		open:	"开启",
		close:	"关闭",
	esee:	"易视网状态",
	ip:		"IP 地址",
	gateway:	"网关",
	netmask:	"子网掩码",
	dns0:		"首选 DNS",
	dns1:		"备用 DNS",
	port:		"端口",
	// remote-ddns
	ddns_set:	"DDNS 设置",
	ddns:		"DDNS 状态",
	server:		"DDNS服务商",
	domain:		"域名",
	user:		"用户名",
	password:	"密码",
	// remote-pppoe
	pppoe_set:	"PPPoE 设置",
	pppoe:		"PPPoE 状态",
	
	//////system setup
	//time
	dev_time:	"设备时间",
	date_frt:	"日期格式",
		date_frt1:	"YMD: xxxx xx xx",
		date_frt2:	"MDY: xx xx xxxx",
		date_frt3:	"DMY: xx xx xxxx",
	date_del:	"日期分隔符",
		date_del1:	"xxxx-xx-xx",
		date_del2:	"xxxx/xx/xx",
		date_del3:	"xxxx.xx.xx",
	time_zone:	"时区",
	daylightt:	"夏时制",
	manual_set:	"手动设置",
	date:	"日期",
	time:	"时间",
	sync_pc_time:	"本地时间设置",
	pc_time:	"当前电脑时间",
	sync:		"同步",
	sync_ntp_time:	"NTP服务同步设置",
	ntp:		"NTP 状态",
	ntp_server:	"NTP 服务商",
	
	//reboot
	reboot_tip:	"按下面的按钮开始重启设备",
	reboot:	"重启",
	
	//restore factory setup
	restore_tip:	"按下面的按钮恢复出厂设置",
	restore: "恢复出厂设置",
	
	//upgrade
	upgrade_tip: "按下面的按钮选择升级文件，并升级",
	upgrade:	"升级",
	
	//device information
	dev_name:	"设备名",
	dev_model:	"设备型号",
	hw_ver:		"硬件版本",
	sw_ver:		"软件版本",
	rel_time:	"发布时间",
	alarm_num:	"报警路数",
	sd_num:		"SD 卡数",
	
	//2013-02-18
	display_net_id_on_screen:"是否在屏幕上显示易视网ID号",
	
	//-----------------------------
	end:	"end"
};
