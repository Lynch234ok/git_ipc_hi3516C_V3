var lang_cookie="juanipcam_lang";
var support_lang="en zh";

function setCookie(c_name,value,exdays)
{
var exdate=new Date();
exdate.setDate(exdate.getDate() + exdays);
var c_value=escape(value) + ((exdays==null) ? "" : "; expires="+exdate.toUTCString());
document.cookie=c_name + "=" + c_value;
}

function getCookie(c_name)
{
var i,x,y,ARRcookies=document.cookie.split(";");
for (i=0;i<ARRcookies.length;i++)
{
  x=ARRcookies[i].substr(0,ARRcookies[i].indexOf("="));
  y=ARRcookies[i].substr(ARRcookies[i].indexOf("=")+1);
  x=x.replace(/^\s+|\s+$/g,"");
  if (x==c_name)
    {
    return unescape(y);
    }
  }
}
	
function getDefaultLanguage()
{
	var type=navigator.appName;
	var i_lang;
	//load from cookie first
	i_lang=getCookie(lang_cookie);
	if(i_lang == null || i_lang == ""){
		if(type=="Netscape"){
		i_lang = navigator.language;
		} else {
		i_lang = navigator.userLanguage;
		}
		//alert("navigator:"+type+", language code:"+i_lang);
		if(i_lang == null || i_lang== ""){ i_lang = "en";}// maybe there is a browser witch don't support internationalization
		if(support_lang.indexOf(i_lang.substring(0,2))<0){ i_lang="en";}// if we don't support this language
		// set cookie
		setCookie(lang_cookie,i_lang.substring(0,2),10);//expire after 10 days
	} else {		
		//alert("get language from cookie : "+i_lang);
	}
	var sz_language="js/"+i_lang.substring(0,2)+".js";	
	//document.write("<id=\"lang_js\" scr"+"ipt src=\""+sz_language+"\"></sc"+"ript>");
	//alert("language: "+sz_language);
	return sz_language;
}

function change_language(sel_lang)
{
var xmlhttp;
// make a async http request
if (window.XMLHttpRequest)
{// code for IE7+, Firefox, Chrome, Opera, Safari
	xmlhttp=new XMLHttpRequest();
}
else
{// code for IE6, IE5
	xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
}
// set onready callback
xmlhttp.onreadystatechange=function()
{
	if (xmlhttp.readyState==4 && xmlhttp.status==200)
	{
		var old_lang_elem=document.getElementById("js_lang");
		var parent_elem=old_lang_elem.parentNode;
		parent_elem.removeChild(old_lang_elem);
		
		eval(xmlhttp.responseText);
		var element=document.getElementById("record");
		element.innerHTML=langstr.record;
	}
}
xmlhttp.open("GET","js/en.js",true);// async
xmlhttp.send();
}

function change_language2(sel_lang)
{
	
var old_lang_elem=document.getElementById("js_lang");
var parent_elem=old_lang_elem.parentNode;
document.getElementById("stream_info").innerHTML=document.getElementById("js_lang").getAttribute("src");
//parent_elem.removeChild(old_lang_elem);
var new_lang_elem=document.createElement("script");
with (new_lang_elem)
{
	setAttribute("id", "js_lang");
	setAttribute("type", "text/javascript");
	setAttribute("src", "js/en.js");
	aync=false;
	//alert("create script success");
}
//lert("create script success 2");

//parent_elem.appendChild(new_lang_elem);
//document.getElementById("stream_info").innerHTML=document.getElementById("js_lang").getAttribute("src");
parent_elem.replaceChild(new_lang_elem,old_lang_elem);
//
var element=document.getElementById("record");
element.innerHTML=langstr.record;
}


function setLanguage(lang)
{
	var cur_lang=getCookie(lang_cookie);
	if(cur_lang == lang){	// same with current
		return;
	}
	if(support_lang.indexOf(lang) < -1){// not support
		lang="en";
	}
	setCookie(lang_cookie,lang,10);
	//change_language(lang); // use for change language without update
	self.location.reload();
}
